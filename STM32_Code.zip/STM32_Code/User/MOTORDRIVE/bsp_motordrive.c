#include "bsp_motordrive.h"
void MOTOROUT_GPIO_Config(void)
{
	GPIO_InitTypeDef   GPIO_InitStruct;
	
	RCC_APB2PeriphClockCmd(OUT1_CLKA11 ,ENABLE);
	GPIO_InitStruct.GPIO_Pin=OUT1_Pin_11;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_Init(OUT1_PORTA11, &GPIO_InitStruct);
	
	RCC_APB2PeriphClockCmd(OUT2_CLKA12 ,ENABLE);
	GPIO_InitStruct.GPIO_Pin=OUT2_Pin_12;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_Init(OUT2_PORTA12, &GPIO_InitStruct);
	
	RCC_APB2PeriphClockCmd(OUT3_CLKF7 ,ENABLE);
	GPIO_InitStruct.GPIO_Pin=OUT3_Pin_7;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_Init(OUT3_PORTF7, &GPIO_InitStruct);
	
	RCC_APB2PeriphClockCmd(OUT4_CLKF8 ,ENABLE);
	GPIO_InitStruct.GPIO_Pin=OUT4_Pin_8;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_Init(OUT4_PORTF8, &GPIO_InitStruct);
	
	
	
	RCC_APB2PeriphClockCmd(LED_G_GPIO_CLKG9 ,ENABLE);
	GPIO_InitStruct.GPIO_Pin=LED_G_GPIO_PING9;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_Init(LED_G_GPIO_PORTG9, &GPIO_InitStruct);
	
}



void Forward(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_3);															
	GPIO_SetBits(GPIOC, GPIO_Pin_2);															
	
	GPIO_ResetBits(GPIOE, GPIO_Pin_6);														
	GPIO_ResetBits(GPIOC, GPIO_Pin_14);														
}

void Backward(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_6);															//INT4=1
	GPIO_SetBits(GPIOC, GPIO_Pin_14);															//INT2=1
	
	GPIO_ResetBits(GPIOE, GPIO_Pin_3);														//INT3=0
	GPIO_ResetBits(GPIOC, GPIO_Pin_2);														//INT1=0	
}

void Turn_Left(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_6);															//INT4=1
	GPIO_SetBits(GPIOC, GPIO_Pin_2);															//INT1=1
	
	GPIO_ResetBits(GPIOE, GPIO_Pin_3);														//INT3=0
	GPIO_ResetBits(GPIOC, GPIO_Pin_14);														//INT2=0	
}

void Turn_Right(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_3);															//INT3=1
	GPIO_SetBits(GPIOC, GPIO_Pin_14);															//INT2=1
	
	GPIO_ResetBits(GPIOE, GPIO_Pin_6);														//INT4=0
	GPIO_ResetBits(GPIOC, GPIO_Pin_2);														//INT1=0	
}	


void Stop(void)
{
	GPIO_ResetBits(GPIOE, GPIO_Pin_3);															//INT3=1
	GPIO_ResetBits(GPIOE, GPIO_Pin_6);															//INT2=1
	
	GPIO_ResetBits(GPIOC, GPIO_Pin_2);														//INT4=0
	GPIO_ResetBits(GPIOC, GPIO_Pin_14);														//INT1=0	
}	



