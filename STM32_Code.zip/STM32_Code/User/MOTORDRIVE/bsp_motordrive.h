#ifndef __BSP_MOTORDRIVE_H
#define __BSP_MOTORDRIVE_H

#include"stm32f10x.h"

#define OUT1_Pin_11     GPIO_Pin_3
#define OUT1_PORTA11    GPIOE
#define OUT1_CLKA11     RCC_APB2Periph_GPIOE

#define OUT2_Pin_12     GPIO_Pin_6
#define OUT2_PORTA12    GPIOE
#define OUT2_CLKA12     RCC_APB2Periph_GPIOE

#define OUT3_Pin_7     GPIO_Pin_2
#define OUT3_PORTF7    GPIOC
#define OUT3_CLKF7     RCC_APB2Periph_GPIOC


#define OUT4_Pin_8     GPIO_Pin_14
#define OUT4_PORTF8    GPIOC
#define OUT4_CLKF8     RCC_APB2Periph_GPIOC



#define LED_G_GPIO_PING9    GPIO_Pin_9
#define LED_G_GPIO_PORTG9    GPIOG
#define LED_G_GPIO_CLKG9     RCC_APB2Periph_GPIOG






void MOTOROUT_GPIO_Config(void);
void Forward(void);
void Backward(void);
void Turn_Left(void);
void Turn_Right(void);
void Stop(void);

#endif /* __BSP_MOTORDRIVE_H */