#ifndef __ADC_H
#define	__ADC_H


#include "stm32f10x.h"
void ADC1_Init(void);
void Delay(__IO uint32_t nCount);
float Random1(void);

#endif /* __ADC_H */

