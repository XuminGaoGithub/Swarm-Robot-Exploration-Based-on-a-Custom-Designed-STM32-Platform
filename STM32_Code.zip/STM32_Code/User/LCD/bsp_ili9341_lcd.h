#ifndef __ILI9341_LCD_H
#define __ILI9341_LCD_H

#include "stm32f10x.h"
#include <stdio.h>

/*LCD�����ź�****************************/

	#define   FSMC_BANK_NORSRAMx		FSMC_Bank1_NORSRAM4

	#define 	ILI9341_CMD_ADDR			(__IO uint16_t *)(0X6C000000)
	#define 	ILI9341_DATA_ADDR			(__IO uint16_t *)(0X6D000000)

	#define 	ILI9341_CS_CLK				RCC_APB2Periph_GPIOG
	#define 	ILI9341_CS_PORT				GPIOG
	#define 	ILI9341_CS_PIN				GPIO_Pin_12

	#define 	ILI9341_RST_CLK				RCC_APB2Periph_GPIOG
	#define 	ILI9341_RST_PORT			GPIOG
	#define 	ILI9341_RST_PIN				GPIO_Pin_11
	
	#define 	ILI9341_BK_CLK				RCC_APB2Periph_GPIOG
	#define 	ILI9341_BK_PORT				GPIOG
	#define 	ILI9341_BK_PIN				GPIO_Pin_6
	
	#define 	ILI9341_RD_CLK				RCC_APB2Periph_GPIOD
	#define 	ILI9341_RD_PORT				GPIOD
	#define 	ILI9341_RD_PIN				GPIO_Pin_4
	
	#define 	ILI9341_WR_CLK				RCC_APB2Periph_GPIOD
	#define 	ILI9341_WR_PORT				GPIOD
	#define 	ILI9341_WR_PIN				GPIO_Pin_5
		
	#define 	ILI9341_DC_CLK				RCC_APB2Periph_GPIOE
	#define 	ILI9341_DC_PORT				GPIOE
	#define 	ILI9341_DC_PIN				GPIO_Pin_2

	
/*LCD�����ź�****************************/

	#define 	ILI9341_D0_CLK		RCC_APB2Periph_GPIOD
	#define 	ILI9341_D0_PORT		GPIOD
	#define 	ILI9341_D0_PIN		GPIO_Pin_14
	
	#define 	ILI9341_D1_CLK		RCC_APB2Periph_GPIOD
	#define 	ILI9341_D1_PORT		GPIOD
	#define 	ILI9341_D1_PIN		GPIO_Pin_15
	
	#define 	ILI9341_D2_CLK		RCC_APB2Periph_GPIOD
	#define 	ILI9341_D2_PORT		GPIOD
	#define 	ILI9341_D2_PIN		GPIO_Pin_0
	
	#define 	ILI9341_D3_CLK		RCC_APB2Periph_GPIOD
	#define 	ILI9341_D3_PORT		GPIOD
	#define 	ILI9341_D3_PIN		GPIO_Pin_1
	
	#define 	ILI9341_D4_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D4_PORT		GPIOE
	#define 	ILI9341_D4_PIN		GPIO_Pin_7
	
	#define 	ILI9341_D5_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D5_PORT		GPIOE
	#define 	ILI9341_D5_PIN		GPIO_Pin_8
	
	#define 	ILI9341_D6_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D6_PORT		GPIOE
	#define 	ILI9341_D6_PIN		GPIO_Pin_9
	
	#define 	ILI9341_D7_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D7_PORT		GPIOE
	#define 	ILI9341_D7_PIN		GPIO_Pin_10
	
	#define 	ILI9341_D8_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D8_PORT		GPIOE
	#define 	ILI9341_D8_PIN		GPIO_Pin_11
	
	#define 	ILI9341_D9_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D9_PORT		GPIOE
	#define 	ILI9341_D9_PIN		GPIO_Pin_12
	
	#define 	ILI9341_D10_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D10_PORT		GPIOE
	#define 	ILI9341_D10_PIN		GPIO_Pin_13
	
	#define 	ILI9341_D11_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D11_PORT		GPIOE
	#define 	ILI9341_D11_PIN		GPIO_Pin_14
	
	#define 	ILI9341_D12_CLK		RCC_APB2Periph_GPIOE
	#define 	ILI9341_D12_PORT		GPIOE
	#define 	ILI9341_D12_PIN		GPIO_Pin_15
	
	#define 	ILI9341_D13_CLK		RCC_APB2Periph_GPIOD
	#define 	ILI9341_D13_PORT		GPIOD
	#define 	ILI9341_D13_PIN		GPIO_Pin_8
	
	#define 	ILI9341_D14_CLK		RCC_APB2Periph_GPIOD
	#define 	ILI9341_D14_PORT		GPIOD
	#define 	ILI9341_D14_PIN		GPIO_Pin_9
	
	#define 	ILI9341_D15_CLK		RCC_APB2Periph_GPIOD
	#define 	ILI9341_D15_PORT		GPIOD
	#define 	ILI9341_D15_PIN		GPIO_Pin_10
	
/*************************************** ����Ԥ�� ******************************************/

#define      DEBUG_DELAY()  

/***************** ILI934 ��ʾ��ȫ��Ĭ�ϣ�ɨ�跽��Ϊ1ʱ�������Ⱥ����߶� *********************/
#define      macILI9341_Default_Max_Width		  240     //��ʼ���X����
#define      macILI9341_Default_Max_Heigth		320     //��ʼ���Y����

/***************************** ILI934 ��ʾ�������ʼ������������� ***************************/
#define      macILI9341_DispWindow_X_Star		    0     //��ʼ���X����
#define      macILI9341_DispWindow_Y_Star		    0     //��ʼ���Y����

#define      macILI9341_DispWindow_COLUMN		  240     //������
#define      macILI9341_DispWindow_PAGE		    320     //������

/******************************* ���� ILI934 �������� ********************************/
#define      CMD_SetCoordinateX		 		    0x2A	     //����X����
#define      CMD_SetCoordinateY		 		    0x2B	     //����Y����
#define      CMD_SetPixel		 		          0x2C	     //�������

/***************************** �� ILI934 ��ʾ������ʾ���ַ��Ĵ�С ***************************/
#define      macWIDTH_EN_CHAR		               8	    //Ӣ���ַ����� 
#define      macHEIGHT_EN_CHAR		            16		  //Ӣ���ַ��߶� 


#define      macWIDTH_CH_CHAR		                16	    //�����ַ����� 
#define      macHEIGHT_CH_CHAR		              16		  //�����ַ��߶� 

#define      macGetGBKCode( ucBuffer, usChar )  	  //�����ȡ�����ַ���ģ����ĺ�������ucBufferΪ�����ģ��������usCharΪ�����ַ��������룩

/******************************* ���� ILI934 ��ʾ��������ɫ ********************************/
#define      macBACKGROUND		                macBLACK   //Ĭ�ϱ�����ɫ

#define      macWHITE		 		                  0xFFFF	   //��ɫ
#define      macBLACK                         0x0000	   //��ɫ 
#define      macGREY                          0xF7DE	   //��ɫ 
#define      macBLUE                          0x001F	   //��ɫ 
#define      macBLUE2                         0x051F	   //ǳ��ɫ 
#define      macRED                           0xF800	   //��ɫ 
#define      macMAGENTA                       0xF81F	   //����ɫ�����ɫ 
#define      macGREEN                         0x07E0	   //��ɫ 
#define      macCYAN                          0x7FFF	   //����ɫ����ɫ 
#define      macYELLOW                        0xFFE0	   //��ɫ 
#define      macBRED                          0xF81F
#define      macGRED                          0xFFE0
#define      macGBLUE                         0x07FF





#define RGB888_2_RGB565(R,G,B)		 (uint16_t)(((R & 0x1F) << 11) | ((G & 0x3F) << 5) | (B & 0x1F) ) 

/*��������*/	
	void ILI9341_Init(void);
	void ILI9341_Draw_Rec(void);
	void ILI9341_GramScan( uint8_t ucOption );
	void ILI9341_Open_Window( uint16_t usX, uint16_t usY, uint16_t usWidth, uint16_t usHeight );
	void ILI9341_Draw_Rec(void);
	void ILI9341_Clear( uint16_t usX, uint16_t usY, uint16_t usWidth, uint16_t usHeight, uint16_t usColor );
	void ILI9341_SetPointPixel( uint16_t usX, uint16_t usY, uint16_t usColor );
	uint16_t ILI9341_GetPointPixel( uint16_t usX, uint16_t usY );
	void ILI9341_DrawLine( uint16_t usX1, uint16_t usY1, uint16_t usX2, uint16_t usY2, uint16_t usColor );
	void ILI9341_DrawRectangle( uint16_t usX_Start, uint16_t usY_Start, uint16_t usWidth, uint16_t usHeight, uint16_t usColor, uint8_t ucFilled );
	void ILI9341_DrawCircle( uint16_t usX_Center, uint16_t usY_Center, uint16_t usRadius, uint16_t usColor, uint8_t ucFilled );
	void ILI9341_DispChar_EN( uint16_t usX, uint16_t usY, const char cChar, uint16_t usColor_Background, uint16_t usColor_Foreground );
	void ILI9341_DispString_EN( uint16_t usX, uint16_t usY, const char *pStr, uint16_t usColor_Background, uint16_t usColor_Foreground );
	void ILI9341_DispChar_CH( uint16_t usX, uint16_t usY, uint16_t usChar, uint16_t usColor_Background, uint16_t usColor_Foreground );
	void ILI9341_DispString_CH( uint16_t usX, uint16_t usY, const uint8_t* pStr, uint16_t usColor_Background, uint16_t usColor_Foreground );
	void ILI9341_DispString_EH_CH( uint16_t usX, uint16_t usY, const uint8_t* pStr, uint16_t usColor_Background, uint16_t usColor_Foreground );

	int GetGBKCode_from_EXFlash( uint8_t * pBuffer, uint16_t c);
	
	__inline void ILI9341_Write_Cmd( uint16_t usCmd );
	__inline void ILI9341_Write_Data( uint16_t usData );


#endif
