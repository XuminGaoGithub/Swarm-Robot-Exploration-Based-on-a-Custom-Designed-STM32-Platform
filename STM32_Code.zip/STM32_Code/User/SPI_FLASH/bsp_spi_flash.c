#include "bsp_spi_flash.h"
#include "bsp_usart.h"

/**
  * @brief SPI_FLASH ��ʼ��
  * @param ��
  * @retval ��
  */
void SPI_FLASH_Init( void )
{
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef SPI_InitStructure;
	
	FLASH_SPI_APBxClock_FUN( FLASH_SPI_CLK, ENABLE );
	
	FLASH_SPI_CS_APBxClock_FUN( FLASH_SPI_CS_CLK | FLASH_SPI_SCK_CLK | FLASH_SPI_MISO_CLK | FLASH_SPI_MOSI_CLK, ENABLE );
	
	//CS
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = FLASH_SPI_CS_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init( FLASH_SPI_CS_PORT, &GPIO_InitStructure );
	
	//SCK
	GPIO_InitStructure.GPIO_Pin = FLASH_SPI_SCK_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init( FLASH_SPI_SCK_PORT, &GPIO_InitStructure );
	
	//MISO
	GPIO_InitStructure.GPIO_Pin = FLASH_SPI_MISO_PIN;
	GPIO_Init( FLASH_SPI_MISO_PORT, &GPIO_InitStructure );
	
	//MOSI
	GPIO_InitStructure.GPIO_Pin = FLASH_SPI_MOSI_PIN;
	GPIO_Init( FLASH_SPI_MOSI_PORT, &GPIO_InitStructure );
	
	FLASH_SPI_CS_HIGH();//CS ����
	
	
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init( FLASH_SPIx, &SPI_InitStructure );
	
	SPI_Cmd( FLASH_SPIx, ENABLE );
}

/**
  * @brief ʹ�� SPI ����һ���ֽڵ�����
  * @param byte��Ҫ���͵�����
  * @retval ���ؽ��յ�������
  */
u8 SPI_FLASH_SendByte( u8 byte )
{
	while (SPI_I2S_GetFlagStatus( FLASH_SPIx, SPI_I2S_FLAG_TXE ) == RESET);
	
	SPI_I2S_SendData( FLASH_SPIx, byte );
	
	while (SPI_I2S_GetFlagStatus( FLASH_SPIx, SPI_I2S_FLAG_RXNE) == RESET);
	
	return SPI_I2S_ReceiveData( FLASH_SPIx );
}

/**
	* @brief ʹ�� SPI ��ȡһ���ֽڵ�����
	* @param ��
	* @retval ���ؽ��յ�������
	*/
u8 SPI_FLASH_ReadByte( void )
{
	return (SPI_FLASH_SendByte( Dummy_Byte ));
}

/**
  * @brief �� FLASH ���� дʹ�� ����
  * @param none
  * @retval none
  */
void SPI_FLASH_WriteEnable( void )
{
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_WriteEnable );
	
	FLASH_SPI_CS_HIGH();
}

/* WIP(busy)��־�� FLASH �ڲ�����д�� */
#define WIP_Flag 0x01

/**
  * @brief �ȴ� WIP(BUSY)��־���� 0�����ȴ��� FLASH �ڲ�����д�����
  * @param none
  * @retval none
  */
void SPI_FLASH_WaitForWriteEnd( void )
{
	u8 FLASH_STATUS = 0;
	
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_ReadStatusReg );
	
	do
	{
		FLASH_STATUS = SPI_FLASH_SendByte( Dummy_Byte );
	}
	while( (FLASH_STATUS & WIP_Flag) == SET );
	
	FLASH_SPI_CS_HIGH();
}

/**
  * @brief ���� FLASH ����
  * @param SectorAddr��Ҫ������������ַ
  * @retval ��
  */
void SPI_FLASH_SectorErase( u32 SectorAddr )
{
	SPI_FLASH_WriteEnable();
	SPI_FLASH_WaitForWriteEnd();
	
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_SectorErase );
	
	SPI_FLASH_SendByte( ( SectorAddr & 0XFF0000 ) >> 16 );
	
	SPI_FLASH_SendByte( ( SectorAddr & 0XFF00 ) >> 8 );
	
	SPI_FLASH_SendByte( ( SectorAddr & 0XFF ) >> 0 );
	
	FLASH_SPI_CS_HIGH();
	
	SPI_FLASH_WaitForWriteEnd();
}

/**
  * @brief 	�������� FLASH ��
  * @param 	��
  * @retval ��
  */
void SPI_FLASH_BulkErase( void )
{
	SPI_FLASH_WriteEnable();
	SPI_FLASH_WaitForWriteEnd();
	
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_ChipErase );
	
	FLASH_SPI_CS_HIGH();
	
	SPI_FLASH_WaitForWriteEnd();
}

/**
  * @brief �� FLASH ��ҳд�����ݣ����ñ�����д������ǰ��Ҫ�Ȳ�������
  * @param pBuffer��Ҫд�����ݵ�ָ��
  * @param WriteAddr��д���ַ
  * @param NumByteToWrite��д�����ݳ��ȣ�����С�ڵ���ҳ��С
  * @retval ��
  */
void SPI_FLASH_PageWrite( u8* pBuffer, u32 WriteAddr, u16 NumByteToWrite )
{
	SPI_FLASH_WriteEnable();
	SPI_FLASH_WaitForWriteEnd();
	
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_PageProgram );
	
	SPI_FLASH_SendByte( ( WriteAddr & 0XFF0000 ) >> 16 );
	
	SPI_FLASH_SendByte( ( WriteAddr & 0XFF00 ) >> 8 );
	
	SPI_FLASH_SendByte( ( WriteAddr & 0XFF ) >> 0 );
	
	if( NumByteToWrite > SPI_FLASH_PerWritePageSize )
	{
		NumByteToWrite = SPI_FLASH_PerWritePageSize;
		printf("SPI_FLASH_PageWrite too large!");
	}
	
	while( NumByteToWrite-- )
	{
		SPI_FLASH_SendByte( *pBuffer );
		pBuffer++;
	}
	
	FLASH_SPI_CS_HIGH();
	
	SPI_FLASH_WaitForWriteEnd();
}

/**
  * @brief �� FLASH д�����ݣ����ñ�����д������ǰ��Ҫ�Ȳ�������
  * @param pBuffer��Ҫд�����ݵ�ָ��
  * @param WriteAddr��д���ַ
  * @param NumByteToWrite��д�����ݳ���
  * @retval ��
  */
void SPI_FLASH_BufferWrite( u8* pBuffer, u32 WriteAddr, u16 NumByteToWrite )
{
	u8 NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;
	
	Addr = WriteAddr & SPI_FLASH_PageSize;
	count = SPI_FLASH_PageSize - Addr;
	NumOfPage = NumByteToWrite / SPI_FLASH_PageSize;
	NumOfSingle = NumByteToWrite % SPI_FLASH_PageSize;
	
	if( Addr == 0 )
	{
		if( NumOfPage == 0 )
		{
			SPI_FLASH_PageWrite( pBuffer, WriteAddr, NumByteToWrite );
		}
		else
		{
			while( NumOfPage-- )
			{
				SPI_FLASH_PageWrite( pBuffer, WriteAddr, SPI_FLASH_PageSize );
				WriteAddr += SPI_FLASH_PageSize;
				pBuffer += SPI_FLASH_PageSize;
			}
			
			SPI_FLASH_PageWrite( pBuffer, WriteAddr, NumOfSingle );
		}
	}
	else
	{
		if( NumOfPage == 0 )
		{
			if( NumOfSingle > count )
			{
				temp = NumOfSingle - count;
				
				SPI_FLASH_PageWrite( pBuffer, WriteAddr, count );
				WriteAddr += count;
				pBuffer += count;
				
				SPI_FLASH_PageWrite( pBuffer, WriteAddr, temp );
			}
			else
			{
				SPI_FLASH_PageWrite( pBuffer, WriteAddr, NumByteToWrite );
			}
		}
		else
		{
			NumByteToWrite -= count;
			NumOfPage = NumByteToWrite / SPI_FLASH_PageSize;
			NumOfSingle = NumByteToWrite % SPI_FLASH_PageSize;
			
			SPI_FLASH_PageWrite( pBuffer, WriteAddr, count );
			WriteAddr += count;
			pBuffer += count;
			
			while( NumOfPage-- )
			{
				SPI_FLASH_PageWrite( pBuffer, WriteAddr, SPI_FLASH_PageSize );
				WriteAddr += SPI_FLASH_PageSize;
				pBuffer += SPI_FLASH_PageSize;
			}
			
			if( NumOfSingle != 0 )
			{
				SPI_FLASH_PageWrite( pBuffer, WriteAddr, NumOfSingle );
			}
		}
	}
}

/**
  * @brief ��ȡ FLASH ����
  * @param pBuffer���洢�������ݵ�ָ��
  * @param ReadAddr����ȡ��ַ
  * @param NumByteToRead����ȡ���ݳ���
  * @retval ��
  */
void SPI_FLASH_BufferRead( u8* pBuffer, u32 ReadAddr, u16 NumByteToRead )
{
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_ReadData );
	
	SPI_FLASH_SendByte( ( ReadAddr & 0XFF0000 ) >> 16 );
	
	SPI_FLASH_SendByte( ( ReadAddr & 0XFF00 ) >> 8 );
	
	SPI_FLASH_SendByte( ( ReadAddr & 0XFF ) >> 0 );
	
	while( NumByteToRead-- )
	{
		*pBuffer = SPI_FLASH_SendByte( Dummy_Byte );
		pBuffer++;
	}
	
	FLASH_SPI_CS_HIGH();
}

/**
 * @brief ��ȡ FLASH ID
 * @param ��
 * @retval FLASH ID
 */
u32 SPI_FLASH_ReadID( void )
{
	u32 Temp0=0, Temp1=0,Temp2=0, Temp=0;
	
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_JedecDeviceID );
	
	Temp0 = SPI_FLASH_SendByte( Dummy_Byte );
	
	Temp1 = SPI_FLASH_SendByte( Dummy_Byte );
	
	Temp2 = SPI_FLASH_SendByte( Dummy_Byte );
	
	FLASH_SPI_CS_HIGH();
	
	Temp = ( Temp0 << 16 ) | ( Temp1 << 8 ) | ( Temp2 << 0 ) ;
	
	return Temp;
}

/**
 * @brief ��ȡ FLASH DEVICE ID
 * @param ��
 * @retval FLASH DEVICE ID
 */
u32 SPI_FLASH_ReadDeviceID( void )
{
	u32 Temp = 0;
	
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_DeviceID );
	
	SPI_FLASH_SendByte( Dummy_Byte );
	
	SPI_FLASH_SendByte( Dummy_Byte );
	
	SPI_FLASH_SendByte( Dummy_Byte );
	
	Temp = SPI_FLASH_SendByte( Dummy_Byte );
	
	FLASH_SPI_CS_HIGH();
	
	return Temp;
}

/**
	* @brief �������ģʽ
	* @param ��
	* @retval ��
	*/
void SPI_FLASH_PowerDown( void )
{
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_PowerDown );
	
	FLASH_SPI_CS_HIGH();
}

/**
	* @brief ����
	* @param ��
	* @retval ��
	*/
void SPI_FLASH_WakeUp( void )
{
	FLASH_SPI_CS_LOW();
	
	SPI_FLASH_SendByte( W25X_ReleasePowerDown );
	
	FLASH_SPI_CS_HIGH();
}

